﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Utility.DataModel
{
    //public class PostLoginModel
    //{
      
    //    public string email { get; set; }
    //    public string password { get; set; }
    //}
}
