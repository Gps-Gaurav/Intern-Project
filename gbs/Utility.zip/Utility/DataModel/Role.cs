﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Utility.DataModel
{
    public struct Role
    {
        public const string Admin = "Admin";
        public const string Guest = "Guest";
    }
}
