﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace gbsinghstoreapi.Models.Common
{
    public enum CommonEnum
    {
        I,R,U,D
    }
}
