﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utility.PostModel
{
    public class SerpModel
    {
        public int id { get; set; }

        public string sku { get; set; }
        public string JsonType { get; set; }
        public string ImageData { get; set; }
        public string JsonData { get; set; }

    }
}
