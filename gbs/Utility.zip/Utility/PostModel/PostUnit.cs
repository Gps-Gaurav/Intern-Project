﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Utility.PostModel
{
    public class PostUnit
    {
        public string unit_name { get; set; }
        public string description { get; set; }
        public int q_id { get; set; }
       
    }
}
