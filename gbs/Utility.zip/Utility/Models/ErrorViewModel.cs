using System;

namespace Utility.Models
{
    public class PostAppModel
    {
        public string type { get; set; }

    }
}
