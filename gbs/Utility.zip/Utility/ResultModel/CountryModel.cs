﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Utility.ResultModel
{
    public class CountryModel
    {
        public int Id { get; set; }
        public string country { get; set; }
        public int status { get; set; }
    }
}
