﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Utility.ResultModel
{
    public class StatusResult
    {
        public int StatusID { get; set; }
        public string StatusMessage { get; set; }
    }
}
