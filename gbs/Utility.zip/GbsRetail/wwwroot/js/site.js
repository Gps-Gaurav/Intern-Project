﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
$(document).on('click', '.add-to-cart', function () {
    var formData = $(this).parents('form:first').serializeArray();
    $('#cartimg').attr('src', formData[3].value);
  //  $('#cart_item_name').val(formData[2].value);
    var anchor = document.getElementById('cart_item_name');
    anchor.innerHTML = anchor.innerHTML + formData[2].value;  
    console.log('Error:', formData[3].value);
    $.ajax({
        type: "POST",
        url: '/Home/cartupdate',

        data: formData,
        success: function (result) {
          
            console.log('cartupdate:', result);
            $('#cart_count').html(result.response);
            
            $('#ltn__utilize-cart-menu').html('');
            getCart();

       
        },
        error: function (data) {
            //console.log('Error:', data);
        }
    });
});


function delete_cartitem(id) {
    var data = {
        id: id

    }

  
    $.ajax({
        type: "POST",
        url: '/Home/cartdelete',

        data: data,
        success: function (result) {
            getCart();

        },
        error: function (data) {
            //console.log('Error:', data);
        }
    });
}

function getCart() {

    $.ajax({
        type: "GET",
        url: '/Home/cartget',
        cache: false,
        async: true,
        dataType: "html",

        success: function (result) {

            $('#ltn__utilize-cart-menu').html(result);

        },
        error: function (data) {
            //console.log('Error:', data);
        }
    });


}

$(document).on('click', '.placeorder', function () {
    var flag = true;
    var pay = document.getElementsByClassName("collapse show")[0].id;
    
   
    function check_field(id) {
        if (!$("#" + id).val().trim()) //Also check Others????
        {
            $('#' + id + '_msg').fadeIn(200).show().html('Required Field').addClass('required');
            // $('#'+id).css({'background-color' : '#E8E2E9'});
            flag = false;
        }
        else {
            $('#' + id + '_msg').fadeOut(200).hide();
            //$('#'+id).css({'background-color' : '#FFFFFF'});    //White color
        }
    }
    check_field("first_name");	
  	
    check_field("email");	
    check_field("phone");	
    check_field("city");	
    check_field("state");	
    check_field("postcode");	
    var pin_code = document.getElementById("postcode");
    var user_mobile = document.getElementById("phone");
    var user_id = document.getElementById("email");
    var pat1 = /^\d{6}$/;
    var pattern = /^\d{10}$/;
    var filter = /^([a-z A-Z 0-9 _\.\-])+\@(([a-z A-Z 0-9\-])+\.)+([a-z A-z 0-9]{3,3})+$/;
    if (!filter.test(user_id.value)) {
        toastr["warning"]("Email is invalid format");
        user_id.focus();
        return false;
    }
    if (!pattern.test(user_mobile.value)) {
        toastr["warning"]("Phone nubmer is invalid format ");
        user_mobile.focus();
        return false;
    }
    if (!pat1.test(pin_code.value)) {
        toastr["warning"]("Pin code should be 6 digits ");
        pin_code.focus();
        return false;
    }


    if (flag == false) {

        toastr["warning"]("You have Missed Something to Fillup!")
        return;
    }
    var formData = $('#name-form').serializeArray();
    console.log('Error:', formData);
    console.log('pay:', pay);
    if (pay === 'UPI') {
        $.ajax({
            type: "POST",
            url: '/PaytmToken',

            data: formData,
            success: function (result) {
                if (result.status == "success") {
                    //alert("Record Saved Successfully!");
                    console.log(result.price)
                    onScriptLoad(result.token, result.order, result.price, "UPI");
                }

            },
            error: function (data) {
                console.log('Error:', data);
            }
        });
    } else { 

        $.ajax({
            type: "POST",
            url: '/CodOrder',

            data: formData,
            success: function (result) {
                if (result.status == "success") {
                    //alert("Record Saved Successfully!");
                    console.log(result.price);
                    window.location.href = '/my-account';
                   
                }

            },
            error: function (data) {
                console.log('Error:', data);
            }
        });
    }
});

function onScriptLoad(txnToken, orderId, amount, payment_option) {
    var config = {
        "root": "",
        "flow": "DEFAULT",
        "payMode": {
            "order": [payment_option]
        },
        "merchant": {
            "name": "GB SINGH",
            "logo": "https://www.gbsretail.com/Images/logo.jpeg?v=1.4"
        },
        "style": {
            "headerBackgroundColor": "#b31a00",
            "headerColor": "#ffffff"
        },
        "data": {
            "orderId": orderId,
            "token": txnToken,
            "tokenType": "TXN_TOKEN",
            "amount": amount
        },
        "handler": {
            "notifyMerchant": function (eventName, data) {
                console.log("payment status ", data);
                if (eventName == 'SESSION_EXPIRED') {
                    alert("Your session has expired!!");
                    location.reload();
                }
            },
            "transactionStatus": function transactionStatus(paymentStatus) {
                console.log("paymentStatus => ", paymentStatus);
            }
        }
    };

    if (window.Paytm && window.Paytm.CheckoutJS) {
        // initialze configuration using init method
        window.Paytm.CheckoutJS.init(config).then(function onSuccess() {
            console.log('Before JS Checkout invoke');
            //$.post("UpdateOrder", { orderId: orderId }, function (result) {
            //    if (result.status == "success") {
            //        //alert("Record Saved Successfully!");
            //        console.log(result.price)
            //        onScriptLoad(result.token, result.order, result.price);
            //    }
            //});
            // after successfully update configuration invoke checkoutjs
            window.Paytm.CheckoutJS.invoke();
        }).catch(function onError(error) {
            console.log("Error => ", error);
        });
    }
}

function remove_cartitem(id) {
    var data = {
        id: id

    }


    $.ajax({
        type: "POST",
        url: '/Home/cartdelete',

        data: data,
        success: function (result) {
            window.location.reload();

        },
        error: function (data) {
            //console.log('Error:', data);
        }
    });
}

function update_cartitem(id,type) {
   
    var data = {
        id: id

    }

    $.ajax({
        type: "POST",
        url: '/Home/cartplusminus?product_id=' + id + '&update_type=' + type,

        data: data,
        success: function (result) {
            window.location.reload();

        },
        error: function (data) {
            //console.log('Error:', data);
        }
    });
}
   